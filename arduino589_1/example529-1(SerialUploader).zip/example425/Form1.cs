﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example425
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[] mydata;
        //주고받는데 사용할 변수
        bool sw = false;
        int count = 0;
        
        double old_x, old_y = 0;
        Queue<int> len = new Queue<int>();

        private void button1_Click(object sender, EventArgs e)
        {
            //버튼 누르면 뭐할래?
            //textBox1.Text
            serialPort1.PortName = textBox1.Text;
            serialPort1.BaudRate = 115200;
            //시리얼포트를 개방한다
            serialPort1.Open();

            MessageBox.Show("연결되었습니다!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //전송버튼 누르면 뭐할래?
            //textBox2.Text

            //보낸다~~~~
            //serialPort1.WriteLine(textBox2.Text);
            count = 0;
            //우체통에 편지가 있으면 비운다
            if (serialPort1.BytesToRead > 0)
            {
                //우체통을 비워라~
                serialPort1.ReadExisting();
            }

            //gcode가 담겨있는 파일을 읽어들여서
            //거기안에 있는 내용을 아두이노로 전송한다!
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open);
                StreamReader sr = new StreamReader(fs);

                string mydatas = sr.ReadToEnd();

                //한줄씩 한줄씩 잘라내라!
                mydata = mydatas.Split('\n');

                sr.Close();
                sr.Dispose();
                fs.Close();
                fs.Dispose();
            }

            backgroundWorker1.RunWorkerAsync();
           

        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            //만약 CNC쪽에서 뭔가 응답이 온다면
            //모든 응답을 다 한큐에 수신한다음
            //sw를 false로 스위칭 해주겠다!
            serialPort1.ReadExisting();
            //송신 재가동
            sw = false;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            //어떤 작업을 하청을 줄래?
            for (int i = 0; i < mydata.Length;)
            {
                //무한루프를 멈출수 있도록 한다
                if (backgroundWorker1.CancellationPending) break;
                
                //전체 작업이 전송가능할때 전송해야한다!
                if (sw == false)
                {
                    //전체 작업현황을 프로그래스바로 표현한다!
                    float percent = ((i + 1) * 100.0f) / mydata.Length;
                    label1.Text = ((int)percent).ToString();
                    backgroundWorker1.ReportProgress((int)percent);

                    listBox1.Items.Add(mydata[i]);

                    //먄약 들어가있는 gcode의 갯수가 11보다 크다면
                    if (listBox1.Items.Count > 11)
                    {
                        //제일 먼저 들어간거 삭제하겠다
                        listBox1.Items.RemoveAt(0);
                    }
                    listBox1.SelectedIndex = listBox1.Items.Count - 1;

                    //gcode 명령어 한줄을 전송한다
                    //mydata[i]
                    //mydata[i]는 \n이 소거된 상태이다
                    //문자열을 utf8로 인코딩한다
                    //=문자열을 byte배열로 바꾼다
                    byte[] gcode = Encoding.UTF8.GetBytes(mydata[i] + '\n');
                    //바뀐 byte배열 전부를 CNC로 전송하라!
                    serialPort1.Write(gcode, 0, gcode.Length);
                    //송신불가
                    sw = true;
                    i++;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            backgroundWorker1.CancelAsync();
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //바뀌는 값을 프로그래스바에 반영하는부분!
            //e.ProgressPercentage
            progressBar1.Value = e.ProgressPercentage;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //홈의 위치로 돌아가라
            //홈의위치는 전원이 들어갔을때 
            //좌표가 0,0이다
            serialPort1.WriteLine("g00 x0 y0");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            serialPort1.WriteLine("g00 x50 y50");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            serialPort1.WriteLine("m3 s0");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            serialPort1.WriteLine("m3 s1000");
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //richTextBox1.Text = mydata.Length + "\n";
            //richTextBox1.Text += count.ToString();
        }
    }
}
