﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Com.Enterprisecoding.RPI.GPIO;
using Com.Enterprisecoding.RPI.GPIO.Enums;


namespace compilepi4
{
    public partial class Form1 : Form
    {
        //C#의 전역변수
        [DllImport("libwiringPi.so", EntryPoint = "digitalRead")]
        private static extern int DigitalReadInt(int pin);

        public static DigitalValue DigitalRead(int pin)
        {
            return (DigitalValue)DigitalReadInt(pin);
        }

        int state = 0;

        public Form1()
        {
            InitializeComponent();

            //메인폼이 실행이되었다!
            OperatingSystem os = System.Environment.OSVersion;
            //지금 운영체제가 라즈베리파이라면~
            if (os.Platform != PlatformID.Win32NT)
            {
                int result = WiringPi.Core.Setup();
                if (result == -1)
                {
                    //실패
                }
                //(출력: 17 ~27)
                for (int i = 17; i <= 27; i++)
                {
                    WiringPi.Core.PinMode(i, PinMode.Output);
                }
                //(입력: 4 ~13, 16)
                for (int i = 4; i <= 13; i++)
                {
                    WiringPi.Core.PinMode(i, PinMode.Input);
                }
                WiringPi.Core.PinMode(16, PinMode.Input);

                timer1.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //WiringPi.Core.DigitalWrite(17, DigitalValue.High);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(state == 0)
            {
                pictureBox1.Image = Properties.Resources.red;
                pictureBox2.Image = Properties.Resources.off;
                pictureBox3.Image = Properties.Resources.off;
                pictureBox4.Image = Properties.Resources.off;
                pictureBox5.Image = Properties.Resources.off;
                WiringPi.Core.DigitalWrite(17, DigitalValue.High);
                WiringPi.Core.DigitalWrite(18, DigitalValue.Low);
                WiringPi.Core.DigitalWrite(19, DigitalValue.Low);
                state++;
            }else if(state == 1)
            {
                pictureBox1.Image = Properties.Resources.off;
                pictureBox2.Image = Properties.Resources.red;
                pictureBox3.Image = Properties.Resources.off;
                pictureBox4.Image = Properties.Resources.off;
                pictureBox5.Image = Properties.Resources.off;
                WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
                WiringPi.Core.DigitalWrite(18, DigitalValue.High);
                WiringPi.Core.DigitalWrite(19, DigitalValue.Low);
                state++;
            }else if(state == 2)
            {
                pictureBox1.Image = Properties.Resources.off;
                pictureBox2.Image = Properties.Resources.off;
                pictureBox3.Image = Properties.Resources.red;
                pictureBox4.Image = Properties.Resources.off;
                pictureBox5.Image = Properties.Resources.off;
                WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
                WiringPi.Core.DigitalWrite(18, DigitalValue.Low);
                WiringPi.Core.DigitalWrite(19, DigitalValue.High);
                state++;
            }else if(state == 3)
            {
                pictureBox1.Image = Properties.Resources.off;
                pictureBox2.Image = Properties.Resources.off;
                pictureBox3.Image = Properties.Resources.off;
                pictureBox4.Image = Properties.Resources.green;
                pictureBox5.Image = Properties.Resources.off;
                WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
                WiringPi.Core.DigitalWrite(18, DigitalValue.Low);
                WiringPi.Core.DigitalWrite(19, DigitalValue.Low);
                state = 0;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.off;
            pictureBox2.Image = Properties.Resources.off;
            pictureBox3.Image = Properties.Resources.off;
            pictureBox4.Image = Properties.Resources.off;
            pictureBox5.Image = Properties.Resources.red;
            WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
            WiringPi.Core.DigitalWrite(18, DigitalValue.Low);
            WiringPi.Core.DigitalWrite(19, DigitalValue.Low);
            state = 0;
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            button2.BackColor = Color.Green;
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            button2.BackColor = SystemColors.Control;
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            button3.BackColor = Color.Red;
        }

        private void button3_MouseUp(object sender, MouseEventArgs e)
        {
            button3.BackColor = SystemColors.Control;
        }
    }
}
