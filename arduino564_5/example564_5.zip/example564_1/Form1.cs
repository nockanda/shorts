﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example564_1
{
    public partial class Form1 : Form
    {
        //1번보드용
        TcpClient tc;
        NetworkStream ns;
        //2번보드용
        TcpClient tc2;
        NetworkStream ns2;

        int x_pos;
        int y_pos;
        bool is_draw = false;
        Bitmap b1 = new Bitmap(296, 128);

        int x_pos2;
        int y_pos2;
        bool is_draw2 = false;
        Bitmap b2 = new Bitmap(296, 128);

        public Form1()
        {
            InitializeComponent();

            Graphics g = Graphics.FromImage(b1);
            g.Clear(Color.White);
            g.Dispose();

            Graphics g2 = Graphics.FromImage(b2);
            g2.Clear(Color.White);
            g2.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //ESP32와 접속한다!
            tc = new TcpClient();
            tc.Connect(textBox1.Text, int.Parse(textBox2.Text));
            ns = tc.GetStream();

            if (tc.Connected)
            {
                MessageBox.Show("성공적으로 접속됨!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //서버와 클라이언트가 접속중이라면~
            if (tc != null)
            {
                tc.Close();
                tc.Dispose();
                ns.Close();
                ns.Dispose();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //사용자가 이미지 경로를 지정하지 않았다면 무시한다!
            if(textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("ERROR!");
                return;
            }

            if(tc == null)
            {
                //TCP연결이 아직 안된상태!
                MessageBox.Show("ERROR!");
                return;
            }

            //검정이미지와 컬러이미지를 mono bitmap으로 변환해야한다!
            Bitmap black_img = new Bitmap(textBox3.Text);
            Bitmap color_img = new Bitmap(textBox4.Text);

            byte[] black = new byte[4736];
            int black_index = 0;
            byte temp = 0;
            byte temp_index = 0;
            for (int i = 0; i < black_img.Width; i++)
            {
                //text1 += "0b";
                for (int j = black_img.Height - 1; j >= 0; j--)
                {

                    //이진화를 해야한다
                    if (black_img.GetPixel(i, j).R > 128)
                    {
                        //드로잉되는 영역
                        //text1 += "1";
                        temp = (byte)(temp | (1 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            //richTextBox1.Text += temp+"("+ black_index+")" + ",";
                            black_index++;
                            temp_index = 0;
                            temp = 0;

                        }
                    }
                    else
                    {
                        temp_index++;
                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            //richTextBox1.Text += temp + "(" + black_index + ")" + ",";
                            black_index++;
                            temp_index = 0;
                            temp = 0;
                        }
                        /*
                        //드로잉되지 않는영역
                        //text1 += "0";
                        temp = (byte)(temp | (0 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            richTextBox1.Text += black[black_index].ToString("X");
                            black_index++;
                            temp_index = 0;
                        }
                        */
                    }
                }
                //text1 += "\n";
            }

            byte[] color = new byte[4736];
            int color_index = 0;

            temp = 0;
            temp_index = 0;
            for (int i = 0; i < color_img.Width; i++)
            {
                //text1 += "0b";
                for (int j = color_img.Height - 1; j >= 0; j--)
                {

                    //이진화를 해야한다
                    if (color_img.GetPixel(i, j).R > 128)
                    {
                        //드로잉되는 영역
                        //text1 += "1";
                        temp = (byte)(temp | (1 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            color[color_index] = temp;
                            //richTextBox1.Text += temp+"("+ black_index+")" + ",";
                            color_index++;
                            temp_index = 0;
                            temp = 0;

                        }
                    }
                    else
                    {
                        temp_index++;
                        if (temp_index > 7)
                        {
                            color[color_index] = temp;
                            //richTextBox1.Text += temp + "(" + black_index + ")" + ",";
                            color_index++;
                            temp_index = 0;
                            temp = 0;
                        }
                    }
                }
                //text1 += "\n";
            }

            black_img.Dispose();
            color_img.Dispose();

            //이미지를 전송한다
            ns.Write(black, 0, black.Length);
            ns.Write(color, 0, color.Length);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //사용자가 이미지 경로를 지정하지 않았다면 무시한다!
            if (textBox9.Text == "" || textBox10.Text == "")
            {
                MessageBox.Show("ERROR!");
                return;
            }

            if (tc == null || tc2 == null)
            {
                //TCP연결이 아직 안된상태!
                MessageBox.Show("ERROR!");
                return;
            }

            //검정이미지와 컬러이미지를 mono bitmap으로 변환해야한다!
            Bitmap black_img = new Bitmap(textBox9.Text);
            Bitmap color_img = new Bitmap(textBox10.Text);

            byte[] black = new byte[4736];
            int black_index = 0;
            byte temp = 0;
            byte temp_index = 0;
            for (int i = 0; i < black_img.Width; i++)
            {
                //text1 += "0b";
                for (int j = black_img.Height - 1; j >= 0; j--)
                {

                    //이진화를 해야한다
                    if (black_img.GetPixel(i, j).R > 128)
                    {
                        //드로잉되는 영역
                        //text1 += "1";
                        temp = (byte)(temp | (1 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            //richTextBox1.Text += temp+"("+ black_index+")" + ",";
                            black_index++;
                            temp_index = 0;
                            temp = 0;

                        }
                    }
                    else
                    {
                        temp_index++;
                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            //richTextBox1.Text += temp + "(" + black_index + ")" + ",";
                            black_index++;
                            temp_index = 0;
                            temp = 0;
                        }
                        /*
                        //드로잉되지 않는영역
                        //text1 += "0";
                        temp = (byte)(temp | (0 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            richTextBox1.Text += black[black_index].ToString("X");
                            black_index++;
                            temp_index = 0;
                        }
                        */
                    }
                }
                //text1 += "\n";
            }

            byte[] color = new byte[4736];
            int color_index = 0;

            temp = 0;
            temp_index = 0;
            for (int i = 0; i < color_img.Width; i++)
            {
                //text1 += "0b";
                for (int j = color_img.Height - 1; j >= 0; j--)
                {

                    //이진화를 해야한다
                    if (color_img.GetPixel(i, j).R > 128)
                    {
                        //드로잉되는 영역
                        //text1 += "1";
                        temp = (byte)(temp | (1 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            color[color_index] = temp;
                            //richTextBox1.Text += temp+"("+ black_index+")" + ",";
                            color_index++;
                            temp_index = 0;
                            temp = 0;

                        }
                    }
                    else
                    {
                        temp_index++;
                        if (temp_index > 7)
                        {
                            color[color_index] = temp;
                            //richTextBox1.Text += temp + "(" + black_index + ")" + ",";
                            color_index++;
                            temp_index = 0;
                            temp = 0;
                        }
                    }
                }
                //text1 += "\n";
            }

            black_img.Dispose();
            color_img.Dispose();

            //이미지를 전송한다
            ns.Write(black, 0, black.Length);
            ns.Write(color, 0, color.Length);
            ns2.Write(black, 0, black.Length);
            ns2.Write(color, 0, color.Length);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox3.Text = openFileDialog1.FileName;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox4.Text = openFileDialog1.FileName;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //ESP32와 접속한다!
            tc2 = new TcpClient();
            tc2.Connect(textBox5.Text, int.Parse(textBox8.Text));
            ns2 = tc2.GetStream();

            if (tc2.Connected)
            {
                MessageBox.Show("성공적으로 접속됨!");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            //서버와 클라이언트가 접속중이라면~
            if (tc2 != null)
            {
                tc2.Close();
                tc2.Dispose();
                ns2.Close();
                ns2.Dispose();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox6.Text = openFileDialog1.FileName;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox7.Text = openFileDialog1.FileName;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //사용자가 이미지 경로를 지정하지 않았다면 무시한다!
            if (textBox6.Text == "" || textBox7.Text == "")
            {
                MessageBox.Show("ERROR!");
                return;
            }

            if (tc2 == null)
            {
                //TCP연결이 아직 안된상태!
                MessageBox.Show("ERROR!");
                return;
            }

            //검정이미지와 컬러이미지를 mono bitmap으로 변환해야한다!
            Bitmap black_img = new Bitmap(textBox6.Text);
            Bitmap color_img = new Bitmap(textBox7.Text);

            byte[] black = new byte[4736];
            int black_index = 0;
            byte temp = 0;
            byte temp_index = 0;
            for (int i = 0; i < black_img.Width; i++)
            {
                //text1 += "0b";
                for (int j = black_img.Height - 1; j >= 0; j--)
                {

                    //이진화를 해야한다
                    if (black_img.GetPixel(i, j).R > 128)
                    {
                        //드로잉되는 영역
                        //text1 += "1";
                        temp = (byte)(temp | (1 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            //richTextBox1.Text += temp+"("+ black_index+")" + ",";
                            black_index++;
                            temp_index = 0;
                            temp = 0;

                        }
                    }
                    else
                    {
                        temp_index++;
                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            //richTextBox1.Text += temp + "(" + black_index + ")" + ",";
                            black_index++;
                            temp_index = 0;
                            temp = 0;
                        }
                        /*
                        //드로잉되지 않는영역
                        //text1 += "0";
                        temp = (byte)(temp | (0 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            richTextBox1.Text += black[black_index].ToString("X");
                            black_index++;
                            temp_index = 0;
                        }
                        */
                    }
                }
                //text1 += "\n";
            }

            byte[] color = new byte[4736];
            int color_index = 0;

            temp = 0;
            temp_index = 0;
            for (int i = 0; i < color_img.Width; i++)
            {
                //text1 += "0b";
                for (int j = color_img.Height - 1; j >= 0; j--)
                {

                    //이진화를 해야한다
                    if (color_img.GetPixel(i, j).R > 128)
                    {
                        //드로잉되는 영역
                        //text1 += "1";
                        temp = (byte)(temp | (1 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            color[color_index] = temp;
                            //richTextBox1.Text += temp+"("+ black_index+")" + ",";
                            color_index++;
                            temp_index = 0;
                            temp = 0;

                        }
                    }
                    else
                    {
                        temp_index++;
                        if (temp_index > 7)
                        {
                            color[color_index] = temp;
                            //richTextBox1.Text += temp + "(" + black_index + ")" + ",";
                            color_index++;
                            temp_index = 0;
                            temp = 0;
                        }
                    }
                }
                //text1 += "\n";
            }

            black_img.Dispose();
            color_img.Dispose();

            //이미지를 전송한다
            ns2.Write(black, 0, black.Length);
            ns2.Write(color, 0, color.Length);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (tc != null)
            {
                tc.Close();
                tc.Dispose();
                ns.Close();
                ns.Dispose();
            }
            if (tc2 != null)
            {
                tc2.Close();
                tc2.Dispose();
                ns2.Close();
                ns2.Dispose();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox9.Text = openFileDialog1.FileName;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox10.Text = openFileDialog1.FileName;
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            x_pos = e.X;
            y_pos = e.Y;
            is_draw = true;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (is_draw)
            {
                int x2_pos = e.X;
                int y2_pos = e.Y;
                Graphics g = Graphics.FromImage(b1);

                Pen p = new Pen(Color.Black, 3);
                g.DrawLine(p, x_pos, y_pos, x2_pos, y2_pos);

                g.Dispose();

                pictureBox1.Image = b1;

                x_pos = x2_pos;
                y_pos = y2_pos;
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            is_draw = false;
        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            x_pos2 = e.X;
            y_pos2 = e.Y;
            is_draw2 = true;
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            if (is_draw2)
            {
                int x2_pos = e.X;
                int y2_pos = e.Y;
                Graphics g = Graphics.FromImage(b2);

                Pen p = new Pen(Color.Black, 3);
                g.DrawLine(p, x_pos2, y_pos2, x2_pos, y2_pos);

                g.Dispose();
                pictureBox2.Image = b2;

                x_pos2 = x2_pos;
                y_pos2 = y2_pos;
            }
        }

        private void pictureBox2_MouseUp(object sender, MouseEventArgs e)
        {
            is_draw2 = false;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (tc == null || tc2 == null)
            {
                //TCP연결이 아직 안된상태!
                MessageBox.Show("ERROR!");
                return;
            }

            //검정이미지와 컬러이미지를 mono bitmap으로 변환해야한다!
            Bitmap black_img = b1;
            Bitmap color_img = b2;

            byte[] black = new byte[4736];
            int black_index = 0;
            byte temp = 0;
            byte temp_index = 0;
            for (int i = 0; i < black_img.Width; i++)
            {
                //text1 += "0b";
                for (int j = black_img.Height - 1; j >= 0; j--)
                {

                    //이진화를 해야한다
                    if (black_img.GetPixel(i, j).R > 128)
                    {
                        //드로잉되는 영역
                        //text1 += "1";
                        temp = (byte)(temp | (1 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            //richTextBox1.Text += temp+"("+ black_index+")" + ",";
                            black_index++;
                            temp_index = 0;
                            temp = 0;

                        }
                    }
                    else
                    {
                        temp_index++;
                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            //richTextBox1.Text += temp + "(" + black_index + ")" + ",";
                            black_index++;
                            temp_index = 0;
                            temp = 0;
                        }
                        /*
                        //드로잉되지 않는영역
                        //text1 += "0";
                        temp = (byte)(temp | (0 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            richTextBox1.Text += black[black_index].ToString("X");
                            black_index++;
                            temp_index = 0;
                        }
                        */
                    }
                }
                //text1 += "\n";
            }

            byte[] color = new byte[4736];
            int color_index = 0;

            temp = 0;
            temp_index = 0;
            for (int i = 0; i < color_img.Width; i++)
            {
                //text1 += "0b";
                for (int j = color_img.Height - 1; j >= 0; j--)
                {

                    //이진화를 해야한다
                    if (color_img.GetPixel(i, j).R > 128)
                    {
                        //드로잉되는 영역
                        //text1 += "1";
                        temp = (byte)(temp | (1 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            color[color_index] = temp;
                            //richTextBox1.Text += temp+"("+ black_index+")" + ",";
                            color_index++;
                            temp_index = 0;
                            temp = 0;

                        }
                    }
                    else
                    {
                        temp_index++;
                        if (temp_index > 7)
                        {
                            color[color_index] = temp;
                            //richTextBox1.Text += temp + "(" + black_index + ")" + ",";
                            color_index++;
                            temp_index = 0;
                            temp = 0;
                        }
                    }
                }
                //text1 += "\n";
            }

            black_img.Dispose();
            color_img.Dispose();

            //이미지를 전송한다
            ns.Write(black, 0, black.Length);
            ns.Write(color, 0, color.Length);
            ns2.Write(black, 0, black.Length);
            ns2.Write(color, 0, color.Length);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            b1.Dispose();
            b2.Dispose();
            b1 = new Bitmap(296, 128);
            b2 = new Bitmap(296, 128);

            Graphics g = Graphics.FromImage(b1);
            g.Clear(Color.White);
            g.Dispose();

            Graphics g2 = Graphics.FromImage(b2);
            g2.Clear(Color.White);
            g2.Dispose();

            pictureBox1.Image = b1;
            pictureBox2.Image = b2;
        }
    }
}
