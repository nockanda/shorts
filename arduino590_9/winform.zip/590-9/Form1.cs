﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _590_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            serialPort1.PortName = textBox1.Text;
            serialPort1.BaudRate = 9600;

            serialPort1.Open();

        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            string data = serialPort1.ReadLine();
            //12.34,56.78
            string[] temp = data.Split(',');
            textBox2.Text = temp[0];
            textBox3.Text = temp[1];

            aGauge1.Value = float.Parse(temp[0]);
            aGauge2.Value = float.Parse(temp[1]);
        }
    }
}
