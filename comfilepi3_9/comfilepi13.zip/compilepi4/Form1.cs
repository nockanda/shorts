﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Com.Enterprisecoding.RPI.GPIO;
using Com.Enterprisecoding.RPI.GPIO.Enums;


namespace compilepi4
{
    public partial class Form1 : Form
    {
        //C#의 전역변수
        [DllImport("libwiringPi.so", EntryPoint = "digitalRead")]
        private static extern int DigitalReadInt(int pin);

        public static DigitalValue DigitalRead(int pin)
        {
            return (DigitalValue)DigitalReadInt(pin);
        }

        DigitalValue[] myio = new DigitalValue[22];
        DigitalValue[] pre_myio = new DigitalValue[22];
        PictureBox[] mypic = new PictureBox[22];
        int[] mypins = { 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27 };

        public Form1()
        {
            InitializeComponent();

            //메인폼이 실행이되었다!
            OperatingSystem os = System.Environment.OSVersion;
            //지금 운영체제가 라즈베리파이라면~
            if (os.Platform != PlatformID.Win32NT)
            {
                int result = WiringPi.Core.Setup();
                if (result == -1)
                {
                    //실패
                }
                //(출력: 17 ~27)
                for (int i = 17; i <= 27; i++)
                {
                    WiringPi.Core.PinMode(i, PinMode.Output);
                }
                //(입력: 4 ~13, 16)
                for (int i = 4; i <= 13; i++)
                {
                    WiringPi.Core.PinMode(i, PinMode.Input);
                }
                WiringPi.Core.PinMode(16, PinMode.Input);

                timer1.Start();
            }

            mypic[0] = pictureBox1;
            mypic[1] = pictureBox2;
            mypic[2] = pictureBox3;
            mypic[3] = pictureBox4;
            mypic[4] = pictureBox5;
            mypic[5] = pictureBox6;
            mypic[6] = pictureBox7;
            mypic[7] = pictureBox8;
            mypic[8] = pictureBox9;
            mypic[9] = pictureBox10;
            mypic[10] = pictureBox11;
            mypic[11] = pictureBox12;
            mypic[12] = pictureBox13;
            mypic[13] = pictureBox14;
            mypic[14] = pictureBox15;
            mypic[15] = pictureBox16;
            mypic[16] = pictureBox17;
            mypic[17] = pictureBox18;
            mypic[18] = pictureBox19;
            mypic[19] = pictureBox20;
            mypic[20] = pictureBox21;
            mypic[21] = pictureBox22;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            /*
            DigitalValue test = DigitalRead(4);
            if(test == DigitalValue.High)
            {
                pictureBox1.Image = Properties.Resources.green;
            }
            else
            {
                pictureBox1.Image = Properties.Resources.off;
            }
            */
            
            for(int i = 0; i < 22; i++)
            {
                myio[i] = DigitalRead(mypins[i]);

                if (pre_myio[i] != myio[i])
                {
                    if (myio[i] == DigitalValue.High)
                    {
                        mypic[i].Image = Properties.Resources.green;
                    }
                    else
                    {
                        mypic[i].Image = Properties.Resources.off;
                    }
                }

                pre_myio[i] = myio[i];
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(17);
            if(now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(17, DigitalValue.High);
            }
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(18);
            if (now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(18, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(18, DigitalValue.High);
            }
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(19);
            if (now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(19, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(19, DigitalValue.High);
            }
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(20);
            if (now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(20, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(20, DigitalValue.High);
            }
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(21);
            if (now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(21, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(21, DigitalValue.High);
            }
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(22);
            if (now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(22, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(22, DigitalValue.High);
            }
        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(23);
            if (now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(23, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(23, DigitalValue.High);
            }
        }

        private void pictureBox19_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(24);
            if (now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(24, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(24, DigitalValue.High);
            }
        }

        private void pictureBox20_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(25);
            if (now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(25, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(25, DigitalValue.High);
            }
        }

        private void pictureBox21_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(26);
            if (now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(26, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(26, DigitalValue.High);
            }
        }

        private void pictureBox22_Click(object sender, EventArgs e)
        {
            DigitalValue now = DigitalRead(27);
            if (now == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(27, DigitalValue.Low);
            }
            else
            {
                WiringPi.Core.DigitalWrite(27, DigitalValue.High);
            }
        }
    }
}
