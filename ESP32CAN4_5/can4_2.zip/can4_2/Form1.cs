﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace can4_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            serialPort1.PortName = textBox1.Text;
            serialPort1.BaudRate = 115200;
            serialPort1.Open();

            if (serialPort1.IsOpen)
            {
                MessageBox.Show("연결되었습니다!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //슬레이브의 아이디
                int id = 0x7E0;
                byte[] data = new byte[10];
                
                data[0] = (byte)(id / 256);
                data[1] = (byte)(id % 256);
                
                for(int i = 0; i < 8; i++)
                {
                    data[i + 2] = (byte)(i + 1);
                }

                //데이터 10byte를 모두 전송해주세요!
                serialPort1.Write(data, 0, 10);

                //응답을 수신해야한다!
                //응답을 기다려야한다!
                //ESP32가 보낸 데이터가 10byte가 될떄까지 기다린다!
                while (true)
                {
                    if(serialPort1.BytesToRead >= 10)
                    {
                        break;
                    }
                }

                byte[] buff = new byte[255];

                int len = serialPort1.Read(buff, 0, buff.Length);

                if(len == 10)
                {
                    //정상
                    for (int i = 0; i < 10; i++)
                    {
                        richTextBox1.Text += buff[i] + ",";
                    }
                    richTextBox1.Text += "\n";
                }
                else
                {
                    //에러
                    richTextBox1.Text += "에러!\n";
                    //에러가 발생하면 수신버퍼 클리어 해버리기
                    serialPort1.ReadExisting();
                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //슬레이브의 아이디
                int id = 0x7E0;
                byte[] data = new byte[10];

                data[0] = (byte)(id / 256);
                data[1] = (byte)(id % 256);

                data[2] = 0; //LED제어명령
                data[3] = 1; //LED 켜져랏!
                /*
                for (int i = 0; i < 8; i++)
                {
                    data[i + 2] = (byte)(i + 1);
                }
                */

                //데이터 10byte를 모두 전송해주세요!
                serialPort1.Write(data, 0, 10);

                //응답을 수신해야한다!
                //응답을 기다려야한다!
                //ESP32가 보낸 데이터가 10byte가 될떄까지 기다린다!
                while (true)
                {
                    if (serialPort1.BytesToRead >= 10)
                    {
                        break;
                    }
                }

                byte[] buff = new byte[255];

                int len = serialPort1.Read(buff, 0, buff.Length);

                if (len == 10)
                {
                    if(buff[3] == 0)
                    {
                        //슬레이쪽 LED가 OFF인상태
                        button3.BackColor = SystemColors.Control;
                        button4.BackColor = Color.Red;
                    }else if (buff[3] == 1)
                    {
                        //슬레이브쪽 LED가 ON인상태
                        button3.BackColor = Color.Green;
                        button4.BackColor = SystemColors.Control;
                    }
                    //정상
                    for (int i = 0; i < 10; i++)
                    {
                        richTextBox1.Text += buff[i] + ",";
                    }
                    richTextBox1.Text += "\n";
                }
                else
                {
                    //에러
                    richTextBox1.Text += "에러!\n";
                    //에러가 발생하면 수신버퍼 클리어 해버리기
                    serialPort1.ReadExisting();
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //슬레이브의 아이디
                int id = 0x7E0;
                byte[] data = new byte[10];

                data[0] = (byte)(id / 256);
                data[1] = (byte)(id % 256);

                data[2] = 0; //LED 제어명령
                data[3] = 0; //LED 꺼져랏!
                /*
                for (int i = 0; i < 8; i++)
                {
                    data[i + 2] = (byte)(i + 1);
                }
                */

                //데이터 10byte를 모두 전송해주세요!
                serialPort1.Write(data, 0, 10);

                //응답을 수신해야한다!
                //응답을 기다려야한다!
                //ESP32가 보낸 데이터가 10byte가 될떄까지 기다린다!
                while (true)
                {
                    if (serialPort1.BytesToRead >= 10)
                    {
                        break;
                    }
                }

                byte[] buff = new byte[255];

                int len = serialPort1.Read(buff, 0, buff.Length);

                if (len == 10)
                {
                    if (buff[3] == 0)
                    {
                        //슬레이쪽 LED가 OFF인상태
                        button3.BackColor = SystemColors.Control;
                        button4.BackColor = Color.Red;
                    }
                    else if (buff[3] == 1)
                    {
                        //슬레이브쪽 LED가 ON인상태
                        button3.BackColor = Color.Green;
                        button4.BackColor = SystemColors.Control;
                    }
                    //정상
                    for (int i = 0; i < 10; i++)
                    {
                        richTextBox1.Text += buff[i] + ",";
                    }
                    richTextBox1.Text += "\n";
                }
                else
                {
                    //에러
                    richTextBox1.Text += "에러!\n";
                    //에러가 발생하면 수신버퍼 클리어 해버리기
                    serialPort1.ReadExisting();
                }

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //슬레이브의 아이디
                int id = 0x7E0;
                byte[] data = new byte[10];

                data[0] = (byte)(id / 256);
                data[1] = (byte)(id % 256);

                data[2] = 1; //가변저항값 주세요!
                /*
                for (int i = 0; i < 8; i++)
                {
                    data[i + 2] = (byte)(i + 1);
                }
                */

                //데이터 10byte를 모두 전송해주세요!
                serialPort1.Write(data, 0, 10);

                //응답을 수신해야한다!
                //응답을 기다려야한다!
                //ESP32가 보낸 데이터가 10byte가 될떄까지 기다린다!
                while (true)
                {
                    if (serialPort1.BytesToRead >= 10)
                    {
                        break;
                    }
                }

                byte[] buff = new byte[255];

                int len = serialPort1.Read(buff, 0, buff.Length);

                if (len == 10)
                {
                    int analog = buff[2] * 256 + buff[3];
                    textBox2.Text = analog.ToString();
                    aGauge1.Value = analog;
                    //정상
                    for (int i = 0; i < 10; i++)
                    {
                        richTextBox1.Text += buff[i] + ",";
                    }
                    richTextBox1.Text += "\n";
                }
                else
                {
                    //에러
                    richTextBox1.Text += "에러!\n";
                    //에러가 발생하면 수신버퍼 클리어 해버리기
                    serialPort1.ReadExisting();
                }
            }
            button7_Click(null, null);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //슬레이브의 아이디
                int id = 0x7E0;
                byte[] data = new byte[10];

                data[0] = (byte)(id / 256);
                data[1] = (byte)(id % 256);

                data[2] = 2;

                //데이터 10byte를 모두 전송해주세요!
                serialPort1.Write(data, 0, 10);

                //응답을 수신해야한다!
                //응답을 기다려야한다!
                //ESP32가 보낸 데이터가 10byte가 될떄까지 기다린다!
                while (true)
                {
                    if (serialPort1.BytesToRead >= 10)
                    {
                        break;
                    }
                }

                byte[] buff = new byte[255];

                int len = serialPort1.Read(buff, 0, buff.Length);

                if (len == 10)
                {
                    double h = (buff[2] * 256 + buff[3]) / 10.0;
                    double t = (buff[4] * 256 + buff[5]) / 10.0;

                    textBox3.Text = h + " %";
                    textBox4.Text = t + " 'C";
                    /*
                    richTextBox1.Text += h + ", " + t + "\n";
                    for (int i = 0; i < 10; i++)
                    {
                        richTextBox1.Text += buff[i] + ",";
                    }
                    richTextBox1.Text += "\n";
                    */
                }
                else
                {
                    //에러
                    richTextBox1.Text += "에러!\n";
                    //에러가 발생하면 수신버퍼 클리어 해버리기
                    serialPort1.ReadExisting();
                }

            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                //슬레이브의 아이디
                int id = int.Parse(textBox5.Text);
                byte[] data = new byte[10];

                data[0] = (byte)(id / 256);
                data[1] = (byte)(id % 256);

                data[2] = byte.Parse(textBox6.Text);
                data[3] = byte.Parse(textBox7.Text);
                data[4] = byte.Parse(textBox8.Text);
                data[5] = byte.Parse(textBox9.Text);
                data[6] = byte.Parse(textBox10.Text);
                data[7] = byte.Parse(textBox11.Text);
                data[8] = byte.Parse(textBox12.Text);
                data[9] = byte.Parse(textBox13.Text);

                //데이터 10byte를 모두 전송해주세요!
                serialPort1.Write(data, 0, 10);

                //응답을 수신해야한다!
                //응답을 기다려야한다!
                //ESP32가 보낸 데이터가 10byte가 될떄까지 기다린다!
                while (true)
                {
                    if (serialPort1.BytesToRead >= 10)
                    {
                        break;
                    }
                }

                byte[] buff = new byte[255];

                int len = serialPort1.Read(buff, 0, buff.Length);

                if (len == 10)
                {
                    //정상
                    for (int i = 0; i < 10; i++)
                    {
                        richTextBox1.Text += buff[i] + ",";
                    }
                    richTextBox1.Text += "\n";
                }
                else
                {
                    //에러
                    richTextBox1.Text += "에러!\n";
                    //에러가 발생하면 수신버퍼 클리어 해버리기
                    serialPort1.ReadExisting();
                }

            }
        }
    }
}
