﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nockanda_printer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        void init_printer()
        {
            byte[] cmd2 = { 27, 64 };
            serialPort1.Write(cmd2, 0, 2);
        }
        void line_feed(byte num)
        {
            byte[] cmd1 = { 27, 100, num };
            serialPort1.Write(cmd1, 0, 3);
        }
        void cut()
        {
            byte[] cmd2 = { 27, 105 };
            serialPort1.Write(cmd2, 0, 2);
        }
        void on_under_line1()
        {
            byte[] cmd3 = { 27, 45, 1 };
            serialPort1.Write(cmd3, 0, 3);
        }
        void on_under_line2()
        {
            byte[] cmd3 = { 27, 45, 2 };
            serialPort1.Write(cmd3, 0, 3);
        }
        void off_under_line()
        {
            byte[] cmd3 = { 27, 45, 0 };
            serialPort1.Write(cmd3, 0, 3);
        }
        void emphasized_on()
        {
            byte[] cmd2 = { 27, 69, 1 };
            serialPort1.Write(cmd2, 0, 3);
        }
        void emphasized_off()
        {
            byte[] cmd2 = { 27, 69, 0 };
            serialPort1.Write(cmd2, 0, 3);
        }
        void double_strike_on()
        {
            byte[] cmd2 = { 27, 71, 1 };
            serialPort1.Write(cmd2, 0, 3);
        }
        void double_strike_off()
        {
            byte[] cmd2 = { 27, 71, 0 };
            serialPort1.Write(cmd2, 0, 3);
        }
        void align_left()
        {
            byte[] cmd2 = { 27, 97, 0 };
            serialPort1.Write(cmd2, 0, 3);
        }
        void align_center()
        {
            byte[] cmd2 = { 27, 97, 1 };
            serialPort1.Write(cmd2, 0, 3);
        }
        void align_right()
        {
            byte[] cmd2 = { 27, 97, 2 };
            serialPort1.Write(cmd2, 0, 3);
        }
        void invert_on()
        {
            byte[] cmd2 = { 29, 66, 1 };
            serialPort1.Write(cmd2, 0, 3);
        }
        void invert_off()
        {
            byte[] cmd2 = { 29, 66, 0 };
            serialPort1.Write(cmd2, 0, 3);
        }
        void set_default_left_magin()
        {
            byte[] cmd2 = { 29, 76, 0, 0 };
            serialPort1.Write(cmd2, 0, 4);
        }
        void set_left_magin(int magin)
        {
            byte nL = (byte)(magin % 256);
            byte nH = (byte)(magin / 256);
            byte[] cmd2 = { 29, 76, nL, nH };
            serialPort1.Write(cmd2, 0, 4);
        }
        void set_default_print_area()
        {
            byte[] cmd2 = { 29, 87, 0, 2 };
            serialPort1.Write(cmd2, 0, 4);
        }
        void set_print_area(int width)
        {
            byte nL = (byte)(width % 256);
            byte nH = (byte)(width / 256);
            byte[] cmd2 = { 29, 87, nL, nH };
            serialPort1.Write(cmd2, 0, 4);

        }
        void set_default_barcode_height()
        {
            byte[] cmd2 = { 29, 104, 162 };
            serialPort1.Write(cmd2, 0, 3);
        }
        void set_barcode_height(byte height)
        {
            byte[] cmd2 = { 29, 104, height };
            serialPort1.Write(cmd2, 0, 3);
        }
        void print_test_barcode()
        {
            //29, 107, 2, 2,0,0,0,0,0,0,2,0,3,4,0,9, 0
            byte[] cmd = { 29, 107, 2 };
            serialPort1.Write(cmd, 0, cmd.Length);
            serialPort1.Write("2000000203409");
            byte[] cmd2 = { 0 }; //NUL
            serialPort1.Write(cmd2, 0, cmd2.Length);
        }
        void set_barcode_width2()
        {
            byte[] cmd2 = { 29, 119, 2 };
            serialPort1.Write(cmd2, 0, cmd2.Length);
        }
        void set_barcode_width3()
        {
            byte[] cmd2 = { 29, 119, 3 };
            serialPort1.Write(cmd2, 0, cmd2.Length);
        }
        void set_barcode_width4()
        {
            byte[] cmd2 = { 29, 119, 4 };
            serialPort1.Write(cmd2, 0, cmd2.Length);
        }
        void set_barcode_width5()
        {        
            byte[] cmd2 = { 29, 119, 5 };
            serialPort1.Write(cmd2, 0, cmd2.Length);
        }
        void set_barcode_width6()
        {

            byte[] cmd2 = { 29, 119, 6 };
            serialPort1.Write(cmd2, 0, cmd2.Length);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                MessageBox.Show("이미 연결되어있습니다!");
                return;
            }

            serialPort1.PortName = textBox1.Text;
            //완성형 한글로 인코딩 수정하기
            serialPort1.Encoding = Encoding.GetEncoding("ks_c_5601-1987");
            serialPort1.Open(); //영수증 프린터와 연결해라!

            if (serialPort1.IsOpen)
            {
                //프린트 초기화
                init_printer();
                //팝업창으로 결과 알림!
                MessageBox.Show("연결되었습니다!");
            }
        }

        void image_print(string path)
        {
            //C#에 이미지를 로드한다!
            Bitmap bt = new Bitmap(path); //컬러이미지
            
            BitArray ba = new BitArray(bt.Width * bt.Height);

            //이진화
            for (int i = 0; i < bt.Width; i++)
            {
                for (int j = 0; j < bt.Height; j++)
                {
                    //bt.SetPixel(i,j)
                    Color c = bt.GetPixel(i, j);
                    int Gray = (int)(0.299 * c.R + 0.587 * c.G + 0.114 * c.B);

                    if (Gray < 100)
                    {
                        bt.SetPixel(i, j, Color.Black);
                    }
                    else
                    {
                        bt.SetPixel(i, j, Color.White);
                    }
                }
            }

            //컬러이미지가 흑백으로 바뀌었다!
            //이미지를 bitarray에 담는다!
            //2차원 이미지를 1차원 바이트 배열로 바꾼것이다!
            int index = 0;
            for (int i = 0; i < bt.Height; i++)
            {
                for (int j = 0; j < bt.Width; j++)
                {
                    if (bt.GetPixel(j, i).R == 255)
                    {
                        ba[index] = false;
                    }
                    else
                    {
                        ba[index] = true;
                    }

                    index++;
                }
            }

            //24개의 라인단위로 위에서부터 아래방향으로 왼쪽으로 오른쪽방향으로
            //픽셀을 순회하면서 list에 순서대로 담는다!
            int z = 0;
            List<byte> img = new List<byte>();
            byte size1 = (byte)(bt.Width / 256);
            byte size2 = (byte)(bt.Width % 256);
            while (z < bt.Height)
            {
                img.Add(27); //이미지헤더
                img.Add(42); //이미지헤더
                img.Add(33); //해상도설정
                img.Add(size2); //사이즈
                img.Add(size1); //사이즈
                for (int x = 0; x < bt.Width; x++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        byte data = 0;
                        for (int b = 0; b < 8; b++)
                        {
                            int y_pos = bt.Width * (b + 8 * k + z) + x;
                            if (y_pos < bt.Width * bt.Height)
                            {
                                data = (byte)(data | (ba[y_pos] ? 1 : 0) << (7 - b));
                            }
                        }
                        img.Add(data);
                    }
                }
                z += 24;
                img.Add(0x0a); //LF
            }
            //byte리스트를 byte배열로 바꿔준다!
            //byte배열은 길이를 미리 정해두고 사용하는것!
            byte[] output = img.ToArray();
            //이미지를 영수증 프린트에 전송한다!
            serialPort1.Write(output, 0, output.Length);

            //열었던 이미지를 닫아주세요!
            bt.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //데이터와 출력명령을 동시에 보내주는 상황
            serialPort1.WriteLine("안녕하세요 녹칸다입니다!");
            //영수증을 절단면을 맞추기 위해 5칸 올린다
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //데이터와 출력명령을 동시에 보내주는 상황
            serialPort1.WriteLine("사과\t복숭아\t포도");
            serialPort1.WriteLine("원숭이\t코끼리\t기린");
            //영수증을 절단면을 맞추기 위해 5칸 올린다
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //데이터와 출력명령을 동시에 보내주는 상황
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            on_under_line1();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            on_under_line2();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            off_under_line();
            //영수증을 절단면을 맞추기 위해 5칸 올린다
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            emphasized_on();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            emphasized_off();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            //영수증을 절단면을 맞추기 위해 5칸 올린다
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            double_strike_on();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            double_strike_off();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            //영수증을 절단면을 맞추기 위해 5칸 올린다
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            align_center();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            align_right();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            align_left();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            //영수증을 절단면을 맞추기 위해 5칸 올린다
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            invert_on();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            invert_off();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            //영수증을 절단면을 맞추기 위해 5칸 올린다
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            set_left_magin(100);
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            set_left_magin(200);
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            set_left_magin(300);
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            set_default_left_magin();
            serialPort1.WriteLine("안녕하세요녹칸다입니다!");
            //영수증을 절단면을 맞추기 위해 5칸 올린다
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            set_barcode_height(40);
            print_test_barcode();
            set_barcode_height(80);
            print_test_barcode();
            set_default_barcode_height();
            set_barcode_width2();
            print_test_barcode();
            set_barcode_width4();
            print_test_barcode();
            set_barcode_width5();
            print_test_barcode();
            set_barcode_width6();
            print_test_barcode();
            set_barcode_width3();
            print_test_barcode();

            //영수증을 절단면을 맞추기 위해 5칸 올린다
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            image_print("test_img.png");
            //영수증을 절단면을 맞추기 위해 5칸 올린다
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            image_print("test_img.png");
            serialPort1.WriteLine("대표: 녹칸다");
            serialPort1.WriteLine("번호: 010-1234-1234");
            serialPort1.WriteLine("-------------------------");
            serialPort1.WriteLine("품목\t수량\t금액");
            serialPort1.WriteLine("바나나\t1\t3000");
            serialPort1.WriteLine("수박\t1\t13000");
            serialPort1.WriteLine("고등어\t1\t7000");
            serialPort1.WriteLine("-------------------------");
            set_barcode_width6();
            set_barcode_height(40);
            print_test_barcode();
            line_feed(5);
            //영수증 프린터를 절단한다
            cut();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            ListViewItem lvi = new ListViewItem();
            lvi.Text = textBox2.Text;
            lvi.SubItems.Add(textBox3.Text);
            lvi.SubItems.Add(textBox4.Text);

            listView1.Items.Add(lvi);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if(listView1.Items.Count == 0)
            {
                MessageBox.Show("출력할 내용이 없습니다!");
            }
            else
            {
                image_print("test_img.png");
                serialPort1.WriteLine("대표: 녹칸다");
                serialPort1.WriteLine("번호: 010-1234-1234");
                serialPort1.WriteLine("-------------------------");

                for(int i = 0; i < listView1.Items.Count; i++)
                {
                    string line = listView1.Items[i].SubItems[0].Text + "\t" + listView1.Items[i].SubItems[1].Text + "\t" + listView1.Items[i].SubItems[2].Text;
                    serialPort1.WriteLine(line);
                    //listView1.Items[i].SubItems[0]
                    //listView1.Items[i].SubItems[1]
                    //listView1.Items[i].SubItems[2]
                }

                serialPort1.WriteLine("-------------------------");
                set_barcode_width6();
                set_barcode_height(40);
                print_test_barcode();
                line_feed(5);
                //영수증 프린터를 절단한다
                cut();
            }
        }
    }
}
