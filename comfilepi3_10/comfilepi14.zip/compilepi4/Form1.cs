﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Com.Enterprisecoding.RPI.GPIO;
using Com.Enterprisecoding.RPI.GPIO.Enums;


namespace compilepi4
{
    public partial class Form1 : Form
    {
        //C#의 전역변수
        [DllImport("libwiringPi.so", EntryPoint = "digitalRead")]
        private static extern int DigitalReadInt(int pin);

        public static DigitalValue DigitalRead(int pin)
        {
            return (DigitalValue)DigitalReadInt(pin);
        }

        DigitalValue old_lamp = DigitalValue.Low;

        public Form1()
        {
            InitializeComponent();

            //메인폼이 실행이되었다!
            OperatingSystem os = System.Environment.OSVersion;
            //지금 운영체제가 라즈베리파이라면~
            if (os.Platform != PlatformID.Win32NT)
            {
                int result = WiringPi.Core.Setup();
                if (result == -1)
                {
                    //실패
                }
                //(출력: 17 ~27)
                for (int i = 17; i <= 27; i++)
                {
                    WiringPi.Core.PinMode(i, PinMode.Output);
                }
                //(입력: 4 ~13, 16)
                for (int i = 4; i <= 13; i++)
                {
                    WiringPi.Core.PinMode(i, PinMode.Input);
                }
                WiringPi.Core.PinMode(16, PinMode.Input);

                timer1.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DigitalValue lamp = DigitalRead(17);

            if (old_lamp != lamp)
            {
                if (lamp == DigitalValue.High)
                {
                    pictureBox1.Image = Properties.Resources.green;
                    pictureBox2.Image = Properties.Resources.off;
                }
                else
                {
                    pictureBox1.Image = Properties.Resources.off;
                    pictureBox2.Image = Properties.Resources.red;
                }
            }

            old_lamp = lamp;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            WiringPi.Core.DigitalWrite(17, DigitalValue.High);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
