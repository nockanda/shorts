﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Com.Enterprisecoding.RPI.GPIO;
using Com.Enterprisecoding.RPI.GPIO.Enums;


namespace compilepi4
{
    public partial class Form1 : Form
    {
        //C#의 전역변수
        [DllImport("libwiringPi.so", EntryPoint = "digitalRead")]
        private static extern int DigitalReadInt(int pin);

        public static DigitalValue DigitalRead(int pin)
        {
            return (DigitalValue)DigitalReadInt(pin);
        }

        Bitmap bt = new Bitmap(723, 319);
        List<int> button = new List<int>();
        List<int> touch = new List<int>();
        List<int> lamp = new List<int>();
        Graphics g;
        bool touch_pressed = false;

        //아두이노의 setup하고 유사한 부분
        public Form1()
        {
            InitializeComponent();

            //메인폼이 실행이되었다!
            OperatingSystem os = System.Environment.OSVersion;
            //지금 운영체제가 라즈베리파이라면~
            if (os.Platform != PlatformID.Win32NT)
            {
                int result = WiringPi.Core.Setup();
                if (result == -1)
                {
                    //실패
                }
                //(출력: 17 ~27)
                for (int i = 17; i <= 27; i++)
                {
                    WiringPi.Core.PinMode(i, PinMode.Output);
                }
                //(입력: 4 ~13, 16)
                for (int i = 4; i <= 13; i++)
                {
                    WiringPi.Core.PinMode(i, PinMode.Input);
                }
                WiringPi.Core.PinMode(16, PinMode.Input);
                
                timer1.Start();
            }
            g = Graphics.FromImage(bt);
            g.DrawLine(Pens.Black, 0, 50, bt.Width, 50);
            g.DrawLine(Pens.Black, 0, 100, bt.Width, 100);
            g.DrawLine(Pens.Black, 0, 150, bt.Width, 150);
            pictureBox1.Image = bt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            //누름버튼을 눌렀다
            touch_pressed = true;
            WiringPi.Core.DigitalWrite(17, DigitalValue.High);
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            //누름버튼을 누르고있다가 뗏다
            touch_pressed = false;
            WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            g.Dispose();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //GPIO의 입출력 상태를 확인한다!
            DigitalValue mybtn = DigitalRead(4); //버튼
            DigitalValue mylamp = DigitalRead(17); //램프
            
            if (mybtn == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(17, DigitalValue.High);
            }
            else
            {
                WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
            }

            //드로잉
            if(button.Count > bt.Width)
            {
                button.RemoveAt(0);
                if (mybtn == DigitalValue.High)
                {
                    button.Add(1);
                }
                else
                {
                    button.Add(0);
                }
            }
            else
            {
                if(mybtn == DigitalValue.High)
                {
                    button.Add(1);
                }
                else
                {
                    button.Add(0);
                }
            }
            if (lamp.Count > bt.Width)
            {
                lamp.RemoveAt(0);
                if (mylamp == DigitalValue.High)
                {
                    lamp.Add(1);
                }
                else
                {
                    lamp.Add(0);
                }
            }
            else
            {
                if (mylamp == DigitalValue.High)
                {
                    lamp.Add(1);
                }
                else
                {
                    lamp.Add(0);
                }
            }

            if (touch.Count > bt.Width)
            {
                touch.RemoveAt(0);
                if (touch_pressed)
                {
                    touch.Add(1);
                }
                else
                {
                    touch.Add(0);
                }
            }
            else
            {
                if (touch_pressed)
                {
                    touch.Add(1);
                }
                else
                {
                    touch.Add(0);
                }
            }
            g.Clear(Color.White);
            for (int i = 0; i < button.Count - 1; i++)
            {
                g.DrawLine(Pens.Red, i, 50-(button[i]*40), i+1, 50-(button[i + 1]*40));
                g.DrawLine(Pens.Blue, i, 100-(touch[i]*40), i + 1, 100-(touch[i + 1]*40));
                g.DrawLine(Pens.Green, i, 150 - (lamp[i] * 40), i + 1, 150 - (lamp[i + 1] * 40));
            }
            pictureBox1.Image = bt;
            //드로잉
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
