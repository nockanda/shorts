﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example619
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //접속버튼을 눌려졌다 뭐할래?
            //시리얼포트를 개방하겠다!
            serialPort1.PortName = textBox1.Text;
            serialPort1.BaudRate = 9600;
            serialPort1.Open();

            if (serialPort1.IsOpen)
            {
                MessageBox.Show("아두이노랑 연결됨!");
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            //아두이노쪽에서 뭔가 왔다 뭐할래?
            string data = serialPort1.ReadLine();
            //data안에 들어있는 값이 CSV형식이다!
            string[] values = data.Split(',');

            if(values.Length == 4)
            {
                //0 : 모터1의 작동상태
                //1 : 모터1의 위치
                //2 : 모터2의 작동상태
                //3 : 모터2의 위치
                textBox3.Text = values[1];
                textBox4.Text = values[3];

                int m1_pos = int.Parse(values[1]);
                int m2_pos = int.Parse(values[3]);

                textBox5.Text = (360 * m1_pos / 4096.0).ToString("F2");
                textBox6.Text = (360 * m2_pos / 4096.0).ToString("F2");

                if (values[0] == "0")
                {
                    textBox3.BackColor = Color.Green;
                    textBox5.BackColor = Color.Green;
                }
                else
                {
                    textBox3.BackColor = Color.Red;
                    textBox5.BackColor = Color.Red;
                }
                if(values[2] == "0")
                {
                    textBox4.BackColor = Color.Green;
                    textBox6.BackColor = Color.Green;
                }
                else
                {
                    textBox4.BackColor = Color.Red;
                    textBox6.BackColor = Color.Red;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //전송버튼 눌러졌다!
            if (serialPort1.IsOpen)
            {
                serialPort1.WriteLine(textBox2.Text);
            }
            else
            {
                MessageBox.Show("아두이노랑 연결해주세요!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.WriteLine("G01 X0 Y0 F1300");
            }
            else
            {
                MessageBox.Show("아두이노랑 연결해주세요!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.WriteLine("G01 X4095 Y4095 F1300");
            }
            else
            {
                MessageBox.Show("아두이노랑 연결해주세요!");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.WriteLine("G01 X1024 Y2048 F1300");
            }
            else
            {
                MessageBox.Show("아두이노랑 연결해주세요!");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.WriteLine("G01 X-2048 Y-1024 F1300");
            }
            else
            {
                MessageBox.Show("아두이노랑 연결해주세요!");
            }
        }
    }
}
