﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using Newtonsoft.Json.Linq;

namespace example571_2
{
    public partial class Form1 : Form
    {
        //전역으로 클래스선언
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //MQTT 브로커와 연결하는 부분
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //연결이 완료되었다!
            //2개 이상의 토픽을 한번에 등록할 경우 문법이 복잡하다!
            //1개만 등록한다고 가정함
            client.Subscribe(new string[] { "nockanda/ina219" }, new byte[] { 0 });
        }
        //MQTT이벤트 핸들러
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            //MQTT메시지가 수신되었다면~
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //ReceivedMessage : JSON
            //역직렬화를 하기 위해서 JSON 라이브러리를 사용하도록함!
            JObject myjson = JObject.Parse(ReceivedMessage);

            //myjson["키값"]

            if (myjson.ContainsKey("BV"))
            {
                //해당 키값이 존재한다
                string bv = myjson["BV"].ToString();
                textBox1.Text = bv;
                aGauge1.Value = float.Parse(bv);
            }

            if (myjson.ContainsKey("SV"))
            {
                string sv = myjson["SV"].ToString();
                textBox2.Text = sv;
                aGauge2.Value = float.Parse(sv);
            }

            if (myjson.ContainsKey("LV"))
            {
                string lv = myjson["LV"].ToString();
                textBox3.Text = lv;
                aGauge3.Value = float.Parse(lv);
            }

            if (myjson.ContainsKey("C"))
            {
                string c = myjson["C"].ToString();
                textBox4.Text = c;
                aGauge4.Value = float.Parse(c); //전류값

                //전류값으로 그래프 그리기(실시간)
                //x축에 20개의 포인트가 그려진다!

                if(chart1.Series[0].Points.Count > 20)
                {
                    //20개보다 점의 갯수가 많은 상황
                    //제일 처음 들어간 데이터 1개 삭제하고
                    chart1.Series[0].Points.RemoveAt(0);
                    //새로운 데이터 집어넣기
                    chart1.Series[0].Points.Add(float.Parse(c));
                }
                else
                {
                    //아직 20개가 아닌 상황
                    chart1.Series[0].Points.Add(float.Parse(c));
                }

                

            }

            if (myjson.ContainsKey("P"))
            {
                string p = myjson["P"].ToString();
                textBox5.Text = p;
                aGauge5.Value = float.Parse(p);
            }
            
            richTextBox1.Text += ReceivedMessage + "\n";
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //MQTT 연결 종료
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //서버와 클라이언트가 연결되어있다면~
            if (client.IsConnected)
            {
                client.Publish("nockanda/relay", Encoding.UTF8.GetBytes("1"), 0, false);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //서버와 클라이언트가 연결되어있다면~
            if (client.IsConnected)
            {
                client.Publish("nockanda/relay", Encoding.UTF8.GetBytes("0"), 0, false);
            }
        }
    }
}
