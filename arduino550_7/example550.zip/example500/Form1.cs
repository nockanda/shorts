﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example500
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            serialPort1.PortName = textBox1.Text;
            serialPort1.Open();

            if (serialPort1.IsOpen)
            {
                MessageBox.Show("연결이 되었습니다!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            byte[] data = new byte[16];
            data[0] = (byte)numericUpDown1.Value;
            data[1] = (byte)numericUpDown2.Value;
            data[2] = (byte)numericUpDown3.Value;
            data[3] = (byte)numericUpDown4.Value;
            data[4] = (byte)numericUpDown5.Value;
            data[5] = (byte)numericUpDown6.Value;
            data[6] = (byte)numericUpDown7.Value;
            data[7] = (byte)numericUpDown8.Value;
            data[8] = (byte)numericUpDown9.Value;
            data[9] = (byte)numericUpDown10.Value;
            data[10] = (byte)numericUpDown11.Value;
            data[11] = (byte)numericUpDown12.Value;
            data[12] = (byte)numericUpDown13.Value;
            data[13] = (byte)numericUpDown14.Value;
            data[14] = (byte)numericUpDown15.Value;
            data[15] = (byte)numericUpDown16.Value;

            serialPort1.Write(data, 0, 16);
        }
    }
}
