﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example437_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //버튼누르면 뭐할래?
            //textBox1.Text
            //시리얼포트에게 아두이노와 연결하라고 할거다!
            //그때 시리얼포트에게 아두이노가 몇번포트에 있는지 알려줘야한다!
            serialPort1.PortName = textBox1.Text;
            serialPort1.Open();
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            //아두이노에서 데이터 받으면 뭐할래?
            string data = serialPort1.ReadLine();

            data = data.Replace("\n", "");
            data = data.Replace("\r", "");

            //listBox1.Items.Add(data);
            string[] datas = data.Split(','); //3

            if(datas.Length == 3)
            {
                if(datas[0] == "0")
                {
                    label2.Text = "가습기 작동여부 : 꺼짐";
                }
                else
                {
                    label2.Text = "가습기 작동여부 : 켜짐";
                }
                
                label3.Text = "습도 : "+datas[1] +" %";
                label4.Text = "온도 : " + datas[2] + " 'C";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //시리얼포트가 열려있냐?
            if (serialPort1.IsOpen)
            {
                char[] mydata = {'1' };
                serialPort1.Write(mydata, 0, 1);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //시리얼포트가 열려있냐?
            if (serialPort1.IsOpen)
            {
                char[] mydata = { '0' };
                serialPort1.Write(mydata, 0, 1);
            }
        }
    }
}
