﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Com.Enterprisecoding.RPI.GPIO;
using Com.Enterprisecoding.RPI.GPIO.Enums;


namespace compilepi4
{
    public partial class Form1 : Form
    {
        //C#의 전역변수
        [DllImport("libwiringPi.so", EntryPoint = "digitalRead")]
        private static extern int DigitalReadInt(int pin);

        public static DigitalValue DigitalRead(int pin)
        {
            return (DigitalValue)DigitalReadInt(pin);
        }

        Bitmap bt = new Bitmap(723, 319);
        List<int> button = new List<int>();
        List<int> button_2 = new List<int>();
        List<int> button_3 = new List<int>();
        List<int> lamp = new List<int>();
        List<int> lamp2 = new List<int>();
        Graphics g;
        bool touch_pressed = false;

        //아두이노의 setup하고 유사한 부분
        public Form1()
        {
            InitializeComponent();

            //메인폼이 실행이되었다!
            OperatingSystem os = System.Environment.OSVersion;
            //지금 운영체제가 라즈베리파이라면~
            if (os.Platform != PlatformID.Win32NT)
            {
                int result = WiringPi.Core.Setup();
                if (result == -1)
                {
                    //실패
                }
                //(출력: 17 ~27)
                for (int i = 17; i <= 27; i++)
                {
                    WiringPi.Core.PinMode(i, PinMode.Output);
                }
                //(입력: 4 ~13, 16)
                for (int i = 4; i <= 13; i++)
                {
                    WiringPi.Core.PinMode(i, PinMode.Input);
                }
                WiringPi.Core.PinMode(16, PinMode.Input);
                
                timer1.Start();
            }
            g = Graphics.FromImage(bt);
            g.DrawLine(Pens.Black, 0, 50, bt.Width, 50);
            g.DrawLine(Pens.Black, 0, 100, bt.Width, 100);
            g.DrawLine(Pens.Black, 0, 150, bt.Width, 150);
            g.DrawLine(Pens.Black, 0, 200, bt.Width, 200);
            g.DrawLine(Pens.Black, 0, 250, bt.Width, 250);
            pictureBox1.Image = bt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            g.Dispose();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //GPIO의 입출력 상태를 확인한다!
            DigitalValue mybtn1 = DigitalRead(4); //버튼1
            DigitalValue mybtn2 = DigitalRead(5); //버튼2
            DigitalValue mybtn3 = DigitalRead(6); //버튼3
            DigitalValue mylamp1 = DigitalRead(17); //램프1
            DigitalValue mylamp2 = DigitalRead(18); //램프2

            
            if (mybtn1 == DigitalValue.High && mylamp2 == DigitalValue.Low)
            {
                WiringPi.Core.DigitalWrite(17, DigitalValue.High);
            }
            if (mybtn2 == DigitalValue.High && mylamp1 == DigitalValue.Low)
            {
                WiringPi.Core.DigitalWrite(18, DigitalValue.High);
            }
            if (mybtn3 == DigitalValue.High)
            {
                WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
                WiringPi.Core.DigitalWrite(18, DigitalValue.Low);
            }
            

            //드로잉
            if(button.Count > bt.Width)
            {
                button.RemoveAt(0);
                button.Add((int)mybtn1);
            }
            else
            {
                button.Add((int)mybtn1);
            }
            if (button_2.Count > bt.Width)
            {
                button_2.RemoveAt(0);
                button_2.Add((int)mybtn2);
            }
            else
            {
                button_2.Add((int)mybtn2);
            }
            if (button_3.Count > bt.Width)
            {
                button_3.RemoveAt(0);
                button_3.Add((int)mybtn3);
            }
            else
            {
                button_3.Add((int)mybtn3);
            }
            if (lamp.Count > bt.Width)
            {
                lamp.RemoveAt(0);
                lamp.Add((int)mylamp1);
            }
            else
            {
                lamp.Add((int)mylamp1);
            }
            if (lamp2.Count > bt.Width)
            {
                lamp2.RemoveAt(0);
                lamp2.Add((int)mylamp2);
            }
            else
            {
                lamp2.Add((int)mylamp2);
            }
            g.Clear(Color.White);
            for (int i = 0; i < button.Count - 1; i++)
            {
                g.DrawLine(Pens.Red, i, 50-(button[i]*40), i+1, 50-(button[i + 1]*40));
                g.DrawLine(Pens.Blue, i, 100-(button_2[i]*40), i + 1, 100-(button_2[i + 1]*40));
                g.DrawLine(Pens.Green, i, 150 - (button_3[i] * 40), i + 1, 150 - (button_3[i + 1] * 40));
                g.DrawLine(Pens.Purple, i, 200 - (lamp[i] * 40), i + 1, 200 - (lamp[i + 1] * 40));
                g.DrawLine(Pens.DeepPink, i, 250 - (lamp2[i] * 40), i + 1, 250 - (lamp2[i + 1] * 40));
            }
            pictureBox1.Image = bt;
            //드로잉
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //버튼1
            DigitalValue mylamp2 = DigitalRead(18); //램프2
            if (mylamp2 == DigitalValue.Low)
            {
                WiringPi.Core.DigitalWrite(17, DigitalValue.High);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //버튼2
            DigitalValue mylamp1 = DigitalRead(17); //램프1
            if (mylamp1 == DigitalValue.Low)
            {
                WiringPi.Core.DigitalWrite(18, DigitalValue.High);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //버튼3
            WiringPi.Core.DigitalWrite(17, DigitalValue.Low);
            WiringPi.Core.DigitalWrite(18, DigitalValue.Low);
        }
    }
}
