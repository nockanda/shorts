﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example563_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("error!");
                return;
            }

            Bitmap black_img = new Bitmap(textBox2.Text);
            Bitmap color_img = new Bitmap(textBox3.Text);

            byte[] black = new byte[4736];
            int black_index = 0;
            byte temp = 0;
            byte temp_index = 0;
            for (int i = 0; i < black_img.Width; i++)
            {
                //text1 += "0b";
                for (int j = black_img.Height - 1; j >= 0; j--)
                {

                    //이진화를 해야한다
                    if (black_img.GetPixel(i, j).R > 128)
                    {
                        //드로잉되는 영역
                        //text1 += "1";
                        temp = (byte)(temp | (1 << (7 - temp_index)));
                        temp_index++;
                        
                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            //richTextBox1.Text += temp+"("+ black_index+")" + ",";
                            black_index++;
                            temp_index = 0;
                            temp = 0;
                            
                        }
                    }
                    else
                    {
                        temp_index++;
                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            //richTextBox1.Text += temp + "(" + black_index + ")" + ",";
                            black_index++;
                            temp_index = 0;
                            temp = 0;
                        }
                        /*
                        //드로잉되지 않는영역
                        //text1 += "0";
                        temp = (byte)(temp | (0 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            black[black_index] = temp;
                            richTextBox1.Text += black[black_index].ToString("X");
                            black_index++;
                            temp_index = 0;
                        }
                        */
                    }
                }
                //text1 += "\n";
            }
            
            byte[] color = new byte[4736];
            int color_index = 0;

            temp = 0;
            temp_index = 0;
            for (int i = 0; i < color_img.Width; i++)
            {
                //text1 += "0b";
                for (int j = color_img.Height - 1; j >= 0; j--)
                {

                    //이진화를 해야한다
                    if (color_img.GetPixel(i, j).R > 128)
                    {
                        //드로잉되는 영역
                        //text1 += "1";
                        temp = (byte)(temp | (1 << (7 - temp_index)));
                        temp_index++;

                        if (temp_index > 7)
                        {
                            color[color_index] = temp;
                            //richTextBox1.Text += temp+"("+ black_index+")" + ",";
                            color_index++;
                            temp_index = 0;
                            temp = 0;

                        }
                    }
                    else
                    {
                        temp_index++;
                        if (temp_index > 7)
                        {
                            color[color_index] = temp;
                            //richTextBox1.Text += temp + "(" + black_index + ")" + ",";
                            color_index++;
                            temp_index = 0;
                            temp = 0;
                        }
                    }
                }
                //text1 += "\n";
            }
            
            black_img.Dispose();
            color_img.Dispose();

            //전송하기
            serialPort1.Write(black, 0, black.Length);
            serialPort1.Write(color, 0, color.Length);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            serialPort1.PortName = textBox1.Text;
            serialPort1.BaudRate = 115200;
            serialPort1.Encoding = Encoding.UTF8;

            serialPort1.Open();

            if (serialPort1.IsOpen)
            {
                MessageBox.Show("connected!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = openFileDialog1.FileName;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox3.Text = openFileDialog1.FileName;
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            richTextBox1.Text += serialPort1.ReadLine() + "\n";
        }
    }
}
