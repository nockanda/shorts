﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;


namespace example556_1
{
    public partial class Form1 : Form
    {
        //C#윈폼의 전역변수 위치
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //메인폼이 실행이 되어서 사용자에게 보여졌을때
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);
            
            //topic은 문자열 배열로 만들것
            string[] mytopic = {"nockanda/esp32/output"};
            //string[] mytopic = {"topic1","topic2",........};
            byte[] myqos = { 0 };

            client.Subscribe(mytopic, myqos);
        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            //메시지가 수신되면 처리되는 부분
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);
            //DO SOMETHING..!

            //ReceivedMessage -> "온도,습도"
            string[] data = ReceivedMessage.Split(',');
            //콤마를 기준으로 온도와 습도가 정확히 나뉘었다
            if(data.Length == 4)
            {
                textBox1.Text = data[0] + "'C";
                textBox2.Text = data[1] + "%";
                textBox3.Text = DateTime.Now.ToString();

                aGauge1.Value = float.Parse(data[0]);
                aGauge2.Value = float.Parse(data[1]);

                //data[2] : LED1의 상태
                //data[3] : LED2의 상태
                if (data[2] == "0")
                {
                    button1.BackColor = SystemColors.Control;
                    button2.BackColor = Color.Red;
                }
                else if(data[2] == "1")
                {
                    button1.BackColor = Color.Green;
                    button2.BackColor = SystemColors.Control;
                }
                if (data[3] == "0")
                {
                    button3.BackColor = SystemColors.Control;
                    button4.BackColor = Color.Red;
                }
                else if (data[3] == "1")
                {
                    button3.BackColor = Color.Green;
                    button4.BackColor = SystemColors.Control;
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //메인폼이 종료되었을때
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //C#이 MQTT서버와 연결되어있다면
            //text를 ESP32로 전송하겠다!
            if (client.IsConnected)
            {
                client.Publish("nockanda/esp32/input", Encoding.UTF8.GetBytes("11"), 0, false);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (client.IsConnected)
            {
                client.Publish("nockanda/esp32/input", Encoding.UTF8.GetBytes("10"), 0, false);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (client.IsConnected)
            {
                client.Publish("nockanda/esp32/input", Encoding.UTF8.GetBytes("21"), 0, false);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (client.IsConnected)
            {
                client.Publish("nockanda/esp32/input", Encoding.UTF8.GetBytes("20"), 0, false);
            }
        }
    }
}
