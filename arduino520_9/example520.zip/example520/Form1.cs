﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example520
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            serialPort1.PortName = textBox1.Text;
            serialPort1.Open();
            MessageBox.Show("연결이 되었습니다!");
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            label1.Text = hScrollBar1.Value.ToString();
            //C#과 아두이노가 연결이 되어있으면 값을 전송하겠다!
            if (serialPort1.IsOpen)
            {
                byte[] data = new byte[1];
                data[0] = (byte)hScrollBar1.Value;
                serialPort1.Write(data, 0, 1);
            }
        }
    }
}
